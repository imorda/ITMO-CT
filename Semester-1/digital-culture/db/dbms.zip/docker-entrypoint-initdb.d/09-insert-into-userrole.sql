USE bloggle;

INSERT INTO `UserRole` (`userId`, `roleName`) VALUES
    (2, 'ADMIN'),
    (3, 'MANAGER'),
    (4, 'WRITER'),
    (5, 'WRITER'),
    (5, 'MANAGER');
